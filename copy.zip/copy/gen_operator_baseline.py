#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""JR東日本・JR東海の baseline_schedule 形式 CSV を作る。

  python3 gen_operator_baseline.py --operator jr-east    --out data/operators/jr-east_baseline_schedule.csv
  python3 gen_operator_baseline.py --operator jr-central --out data/operators/jr-central_baseline_schedule.csv

════════════════════════════════════════════════════════════════════════════════
このファイルの中身は2種類あります。混ぜないでください。
════════════════════════════════════════════════════════════════════════════════

【実データ】公開情報で裏を取ったもの ── ROSTER / RULES に出典を付けて記載
   ・形式、編成記号、両数、本数、投入期間、引退時期
   ・検査周期（省令の既定と、各社・各形式の延伸）

【構成値】公開されていないため、規定から組み立てたもの ── 月ごとの検査セル
   ・どの編成がいつ台車検査／全般検査を受けたか、という 1 本ごとの実施月
   ・**これはどの事業者も公表していません。** JR西日本の baseline_schedule.csv も
     お客様から提供されたもので、調べて作れる類のデータではありません。
   ・ここでは「規定の上限で回し続けた場合」の理想形を敷いています。実績ではありません。

したがってこの CSV は、エンジンの検証・規模感の確認には使えますが、
**実績として引用してはいけません。** 出力の1行目にもその旨を書き込みます。
"""
from __future__ import annotations

import argparse
import csv
import os

# ════════════════════════════════════════════════════════════════════════════
# 検査周期 ── 実データ（省令の既定 ＋ 各社の延伸）
# ════════════════════════════════════════════════════════════════════════════
# 既定（国土交通省告示ベース。全事業者共通の出発点）
#   仕業検査 48時間 / 交番検査 30日 or 3万km / 台車検査 18か月 or 60万km / 全般検査 36か月 or 120万km
# 延伸（事業者・形式・時期ごとに異なる — だからルールは定数ではなく (形式, 日付) で解決する）
#   JR東海: 2022-04〜 N700S および N700A 新製車(1000番台G編成)
#           台車 18か月/60万km → 20か月/80万km、全般 36か月/120万km → 40か月/160万km
#           （年間約40億円の削減。2026年度末までに対象車へ順次拡大）
#   JR東日本: 2021-02-15 以降に全般検査を施行した E5・E6・E7 系から順次
#           台車 18か月/60万km → 80万km【時間規定なし】
#           全般 36か月/120万km → 160万km【時間規定なし】
#           ＝ 距離のみで判定する「新保全体系」。時間では期限が来ない。
RULES = {
    "default":            {"bogie_m": 18, "bogie_km": 600_000,  "gen_m": 36, "gen_km": 1_200_000},
    "jr-central_ext":     {"bogie_m": 20, "bogie_km": 800_000,  "gen_m": 40, "gen_km": 1_600_000},
    "jr-east_distance":   {"bogie_m": None, "bogie_km": 800_000, "gen_m": None, "gen_km": 1_600_000},
}

# 月あたり走行キロ ── 距離規定を月へ換算するのに要る。**推定値（要検証）**だが、当てずっぽうではない:
# 既定の周期が「18か月 または 60万km」と対で定められている以上、規制側は標準的な編成が
# 60万km を約18か月で走ると見ている。つまり 60万 ÷ 18 ≈ 33,300 km/月 が設計上の想定値。
# これを出発点に、東海道（高頻度・折返し多い）をやや高め、東日本（長距離だが本数は少ない）を
# やや低めに置く。実績が入れば置き換える。
MONTHLY_KM = {"jr-central": 34_000, "jr-east": 30_000}

# ════════════════════════════════════════════════════════════════════════════
# 名簿 ── 実データ（出典は README と下のコメント）
#   (系列, 編成記号, 両数, 本数, 投入 開始/終了, 引退 開始/終了, ルール鍵)
#   投入・引退は「その期間に均等に配分」する。1本ごとの正確な日付までは公表されていないため。
# ════════════════════════════════════════════════════════════════════════════
ROSTER = {
    # ── JR東海 東海道新幹線（車両基地: 東京・大井 / 三島 / 名古屋 / 大阪・鳥飼）────────
    # 出典: JR東海 公式（N700S 車両案内・検査周期延伸リリース）, 各形式 Wikipedia
    "jr-central": {
        "depot": "東京第一車両所ほか（東海道新幹線）",
        "series": [
            # 300系 J編成 16両 61本 1992-1998投入 2012-03 全廃
            ("300",    "J", 16, 61, (1992, 3), (1998, 3), (2007, 4), (2012, 3), "default"),
            # 700系 C編成 16両 60本 1999-2006投入 2020-03 引退
            ("700",    "C", 16, 60, (1999, 3), (2006, 3), (2018, 4), (2020, 3), "default"),
            # N700系 X編成(旧Z編成) 16両 80本 2007-2012投入 2020-07 廃車開始
            ("N700",   "X", 16, 80, (2007, 7), (2012, 3), (2020, 7), (2026, 3), "default"),
            # N700A G編成 16両 51本 2013-02 営業開始〜2020
            ("N700A",  "G", 16, 51, (2013, 2), (2020, 3), None, None, "jr-central_ext"),
            # N700S J編成 16両 56本 2020-07 営業開始〜2025年度（2026-04-01 時点 56本）
            ("N700S",  "J", 16, 56, (2020, 7), (2026, 3), None, None, "jr-central_ext"),
        ],
    },
    # ── JR東日本 東北・上越・北陸・山形・秋田新幹線 ────────────────────────────
    # 出典: JR東日本「保有車両一覧」2025-04-01（形式別 両数・平均経年）, 各形式 Wikipedia
    #   E8系 63両/7両=9本, E7系 468両/12両=39本, E6系 161両/7両=23本,
    #   E5系 510両/10両=51本, E3系 56両/7両=8本, E2系 70両/10両=7本
    "jr-east": {
        "depot": "新幹線総合車両センターほか（東北・上越・北陸）",
        "series": [
            # E2系 J編成 10両 — 1997投入。公式一覧(2025-04-01)で 70両=7本が【在籍中】。
            # E3系 L編成 7両 — 山形新幹線用。同 56両=8本が【在籍中】（E8系へ置換が進行中）。
            # どちらも公式一覧に載っている＝その時点で在籍しているということなので、引退は入れない。
            # 置換がいつ完了するかは公表されていない。分からないものを日付として書かない。
            ("E2",  "J", 10,  7, (1997, 3), (2005, 3), None, None, "default"),
            ("E3",  "L",  7,  8, (1999, 3), (2010, 3), None, None, "default"),
            # E5系 U編成 10両 51本 — 2011-03 営業開始
            ("E5",  "U", 10, 51, (2011, 3), (2022, 3), None, None, "jr-east_distance"),
            # E6系 Z編成 7両 23本 — 2013-03 営業開始
            ("E6",  "Z",  7, 23, (2013, 3), (2014, 3), None, None, "jr-east_distance"),
            # E7系 F編成 12両 39本 — 2014-03 営業開始（2019年台風で一部被災・補充新製）
            ("E7",  "F", 12, 39, (2014, 3), (2025, 3), None, None, "jr-east_distance"),
            # E8系 G編成 7両 9本 — 2024-03 営業開始
            ("E8",  "G",  7,  9, (2024, 3), (2026, 3), None, None, "default"),
        ],
    },
}

FIRST_INSPECTION_M = 30      # 新製から初回検査まで ≈30か月（JR西日本の実績から）
JR_EAST_NEW_RULE_FROM = (2021, 2)     # E5/E6/E7 の距離規定へ切替（全般検査の施行順に順次）
JR_CENTRAL_EXT_FROM = (2022, 4)       # N700S / N700A新製車 の周期延伸


def mi(y: int, m: int) -> int:
    return y * 12 + (m - 1)


def ym(i: int) -> tuple[int, int]:
    return i // 12, i % 12 + 1


def _interval(rule_key: str, kind: str, at: int, operator: str) -> int:
    """その時点で有効な検査間隔（か月）。時間規定と距離規定の早いほうを取る。

    距離規定しか無い形式（JR東日本 E5以降）は距離だけで決まる — 時間では期限が来ない。
    延伸は施行日より前には効かないので、日付で切り替える。
    """
    key = rule_key
    if rule_key == "jr-central_ext" and at < mi(*JR_CENTRAL_EXT_FROM):
        key = "default"
    if rule_key == "jr-east_distance" and at < mi(*JR_EAST_NEW_RULE_FROM):
        key = "default"
    r = RULES[key]
    km_per_month = MONTHLY_KM[operator]
    by_km = int(r[f"{kind}_km"] / km_per_month)
    by_month = r[f"{kind}_m"]
    return by_km if by_month is None else min(by_month, by_km)


def build(operator: str, start: tuple[int, int], end: tuple[int, int]) -> tuple[list[str], list[list[str]]]:
    spec = ROSTER[operator]
    i0, i1 = mi(*start), mi(*end)
    months = list(range(i0, i1 + 1))
    header = ["系列", "編成", "番号", "set_id", "cars", "subtype"] + [f"{ym(x)[0]}-{ym(x)[1]:02d}" for x in months]

    rows: list[list[str]] = []
    for series, form, cars, n, new_a, new_b, ret_a, ret_b, rule in spec["series"]:
        a, b = mi(*new_a), mi(*new_b)
        ra = mi(*ret_a) if ret_a else None
        rb = mi(*ret_b) if ret_b else None
        for k in range(n):
            # 投入は期間内に均等配分（1本ごとの正確な日付は公表されていないため）
            born = a if n == 1 else a + round((b - a) * k / (n - 1))
            gone = None
            if ra is not None and rb is not None:
                gone = ra if n == 1 else ra + round((rb - ra) * k / (n - 1))
            cells = [""] * len(months)

            def put(idx: int, token: str):
                if i0 <= idx <= i1:
                    p = idx - i0
                    cells[p] = f"{cells[p]}/{token}" if cells[p] else token

            if i0 <= born <= i1:
                put(born, "New")
            # 検査のリズム: 台車 → 全般 を交互に、その時点で有効な上限いっぱいで。
            #
            # ただし初回だけは、その系列の中で1周期ぶん均等にずらす。ずらさないと、投入期間が短い系列
            # （E6系は23本を13か月で投入）が永久に横並びで動き、同じ月に一斉入場する。実測では
            # 計画開始月に51件（JR東日本）が集中し、どの入場枠でも収まらなかった。
            # 現実の車両所は意図的にずらして平すので、横並びのほうが不自然。
            cycle = _interval(rule, "bogie", born + FIRST_INSPECTION_M, operator)
            cur = born + FIRST_INSPECTION_M + (k * cycle // max(1, n)) % cycle
            is_gen = False
            guard = 0
            while cur <= (gone if gone is not None else i1) and guard < 200:
                guard += 1
                put(cur, "全般検査" if is_gen else "台車検査")
                step = _interval(rule, "gen" if is_gen else "bogie", cur, operator)
                cur += step
                is_gen = not is_gen
            if gone is not None and i0 <= gone <= i1:
                # 本体パーサが解釈できる結合語は「全般検査/Retired」だけ。台車検査と重なった場合は
                # 検査のほうを退ける — 廃車直前の台車検査は現実にも行わない（M6 の pre-retire 判断と同じ）。
                pos = gone - i0
                if cells[pos] == "台車検査":
                    cells[pos] = ""
                put(gone, "Retired")
            rows.append([series, form, str(k + 1), f"{form}{k + 1}", str(cars),
                         f"{series} {cars}両"] + cells)
    return header, rows


# ════════════════════════════════════════════════════════════════════════════
# 事業者ごとの周期設定（reference_values.yaml の上書き）
# ════════════════════════════════════════════════════════════════════════════
# **会社をまたぐ1つのファイルに系列単位の上書きを置いてはいけない。** 系列名は会社をまたいで
# 共通なので、他社に漏れる。実例: JR東海の延伸を共通ファイルに入れたところ、JR西日本の
# N700S 5本・N700A 40本 の周期まで変わってしまった（JR東海の延伸は JR西日本に未確認）。
# だから会社ごとに別ファイルにし、その会社の baseline とだけ組で使う。
OPERATOR_OVERRIDES = {
    "jr-central": [
        {"series": ["N700S", "N700A"], "from": "2022-04",
         "bogie_m": 20, "bogie_km": 800_000, "gen_m": 40, "gen_km": 1_600_000,
         "note": "JR東海 2022-04〜 N700S・N700A新製車(1000番台G編成)。年約40億円削減、2026年度末まで順次拡大。"},
    ],
    "jr-east": [
        # 距離のみ。時間では期限が来ない。エンジンは min(時間, 距離) で判定するので、
        # 時間側は「距離が先に来ることが確実な大きな値」を置いて実質無効化する。
        {"series": ["E5", "E6", "E7"], "from": "2021-02",
         "bogie_m": 999, "bogie_km": 800_000, "gen_m": 999, "gen_km": 1_600_000,
         "note": "JR東日本 新保全体系 2021-02-15〜 E5/E6/E7。台車80万km・全般160万km の【距離規定のみ】。"
                 "時間規定は存在しないため、月数は実質無効の大きな値を置いている。"},
    ],
}


def emit_reference(operator: str, base_path: str, out: str) -> None:
    """その会社の baseline とだけ組で使う reference_values.yaml を書き出す。

    共通ファイルをそのまま読み込み、`inspection_rules.overrides` だけ差し替える。
    ¥ の前提など他の項目は共通のまま（会社ごとの実績が入るまで動かす根拠が無い）。
    """
    import yaml
    with open(base_path, encoding="utf-8") as fh:
        ref = yaml.safe_load(fh)
    ov = []
    for o in OPERATOR_OVERRIDES.get(operator, []):
        ov.append({
            "applies_to_series": o["series"],
            "effective_from": o["from"],
            "note": o["note"],
            "bogie_台車検査": {"interval_months": o["bogie_m"],
                              "interval_km": {"low": int(o["bogie_km"] * 0.9),
                                              "mid": o["bogie_km"],
                                              "high": int(o["bogie_km"] * 1.1)}},
            "general_全般検査": {"interval_months": o["gen_m"],
                               "interval_km": {"low": int(o["gen_km"] * 0.9),
                                               "mid": o["gen_km"],
                                               "high": int(o["gen_km"] * 1.1)}},
        })
    ref["inspection_rules"]["overrides"] = ov
    ref["inspection_rules"]["note"] = (
        f"{operator} 専用。系列名は会社をまたいで共通なので、この上書きを共通ファイルへ移してはいけない。")
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(f"# {operator} 専用の前提レジストリ — gen_operator_baseline.py が生成\n"
                 f"# 同社の baseline_schedule CSV とだけ組で使うこと。\n"
                 f"# 出典と限界: data/operators/README.md\n")
        yaml.safe_dump(ref, fh, allow_unicode=True, sort_keys=False, width=120)
    print(f"{operator}: 周期設定 {len(ov)} 件 → {out}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--operator", required=True, choices=sorted(ROSTER))
    ap.add_argument("--out", required=True)
    ap.add_argument("--from-ym", default="1992-04")
    ap.add_argument("--to-ym", default="2027-03")
    ap.add_argument("--emit-ref", default=None,
                    help="この会社専用の reference_values.yaml も書き出す（baseline と組で使う）")
    ap.add_argument("--base-ref", default="data/reference/reference_values.yaml")
    a = ap.parse_args()

    start = tuple(int(v) for v in a.from_ym.split("-"))
    end = tuple(int(v) for v in a.to_ym.split("-"))
    header, rows = build(a.operator, start, end)

    banner = [""] * 6
    for j, lab in enumerate(header[6:]):
        y, m = (int(v) for v in lab.split("-"))
        banner.append(f"{y if m >= 4 else y - 1}年度" if m == 4 else "")
    # 1行目の先頭に、この表の性格を書き込む（切り離されても付いて回るように）
    banner[0] = ("【注意】名簿(系列/編成/両数/新製/引退)と検査周期は公開情報。"
                 "月ごとの検査セルは規定の上限から構成した値で、実績ではありません。")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with open(a.out, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(banner)
        w.writerow(header)
        w.writerows(rows)

    if a.emit_ref:
        emit_reference(a.operator, a.base_ref, a.emit_ref)

    ev = sum(1 for r in rows for c in r[6:] if c)
    print(f"{a.operator}: {len(rows)} 編成 × {len(header) - 6} か月 / 記録 {ev} 件 → {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
